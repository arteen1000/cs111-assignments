# Hash Hash Hash
This lab xxx

## Building
```shell

```

## Running
```shell

```

## First Implementation
In the `hash_table_v1_add_entry` function, xxx

### Performance
```shell

```

This time version 1 is xxx

## Second Implementation
In the `hash_table_v2_add_entry` function, xxx

### Performance
```shell

```

This time the speed up is xxx

## Cleaning up
```shell

```